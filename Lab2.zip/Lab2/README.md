# SSVT 2019
## Group 2
### Members:
- Hendrik Huang
- Mike Mourcous
- Patrick Fennema
- Wouter Loeve

## Lab2 :
Can be found in the Lab2/ folder. Running is done by: `stack build; stack exec solutions-stack-exe`
